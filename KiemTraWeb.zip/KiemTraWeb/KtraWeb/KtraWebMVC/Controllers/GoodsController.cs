﻿using KtraWebMVC.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace KtraWebMVC.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
