﻿namespace KtraWebMVC.Models
{
    public class Goods
    {
        public int MaHangHoa { get; set; }
        public string TenHangHoa { get; set; } = string.Empty;
        public int SoLuong { get; set; }
        public string GhiChu { get; set; } = string.Empty;
    }
}
