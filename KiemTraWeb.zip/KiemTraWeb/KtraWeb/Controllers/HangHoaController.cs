﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using KtraWeb.API.Data;
using KtraWeb.API.Models;

namespace KtraWeb.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HangHoaController : ControllerBase
    {
        private readonly AppDbContext _context;

        public HangHoaController(AppDbContext context)
        {
            _context = context;
        }

        // Lấy danh sách hàng hóa
        [HttpGet]
        public async Task<ActionResult<IEnumerable<HangHoa>>> GetAll()
        {
            return await _context.Goods.ToListAsync();
        }

        // Lấy hàng hóa theo mã
        [HttpGet("{id}")]
        public async Task<ActionResult<HangHoa>> GetById(string id)
        {
            var hangHoa = await _context.Goods.FindAsync(id);
            if (hangHoa == null)
                return NotFound();
            return hangHoa;
        }

        // Thêm hàng hóa
        [HttpPost]
        public async Task<ActionResult<HangHoa>> Create(HangHoa hangHoa)
        {
            _context.Goods.Add(hangHoa);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetById), new { id = hangHoa.MaHangHoa }, hangHoa);
        }

        // Cập nhật hàng hóa
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, HangHoa hangHoa)
        {
            if (id != hangHoa.MaHangHoa)
                return BadRequest();

            _context.Entry(hangHoa).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // Xóa hàng hóa
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            var hangHoa = await _context.Goods.FindAsync(id);
            if (hangHoa == null)
                return NotFound();

            _context.Goods.Remove(hangHoa);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}
