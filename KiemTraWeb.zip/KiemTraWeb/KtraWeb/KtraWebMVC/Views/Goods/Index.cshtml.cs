using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KtraWeb.KtraWebMVC.Views.Goods
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
