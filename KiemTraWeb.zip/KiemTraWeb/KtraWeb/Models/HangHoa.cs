﻿using System.ComponentModel.DataAnnotations;

namespace KtraWeb.API.Models
{
    public class HangHoa
    {
        [Key]
        [StringLength(9)]
        public string MaHangHoa { get; set; } = null!;

        [Required]
        public string TenHangHoa { get; set; } = null!;

        public int SoLuong { get; set; }

        public string? GhiChu { get; set; }
    }
}
