﻿using Microsoft.EntityFrameworkCore;
using KtraWeb.API.Models;

namespace KtraWeb.API.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<HangHoa> Goods { get; set; }
    }
}
